
webix.ready(function(){
	if (webix.CustomScroll)
		webix.CustomScroll.init();
	webix.ui({
	"rows": [
		{
			"view": "toolbar",
			"css": "webix_dark",
			"paddingX": 5,
			"cols": [
				{
					"view": "icon",
					"icon": "wxi-clock"
				},
				{
					"view": "label",
					"label": "Event Planner"
				},
				{
					"view": "button",
					"label": "Close",
					"width": 80
				}
			]
		},
		{
			"view": "form",
			"margin": 40,
			"rows": [
				{
					"margin": 20,
					"cols": [
						{
							"margin": 10,
							"rows": [
								{
									"view": "template",
									"type": "section",
									"template": "Menu utilisateur"
								},
								{
									"label": "M'ajouter comme client",
									"view": "button",
									"height": 38
								},
								{
									"cols": [
										{
											"view": "text",
											"placeholder": "Type here...",
											"label": "Cip",
											"labelWidth": 100
										},
										{
											"label": "Ajouter Admin",
											"view": "button",
											"height": 38
										}
									]
								}
							]
						},
						{
							"margin": 10,
							"rows": [
								{
									"view": "template",
									"type": "section",
									"template": "Menu produit"
								},
								{
									"label": "Nom",
									"view": "text",
									"height": 38
								},
								{
									"label": "Description",
									"view": "text",
									"height": 38
								},
								{
									"label": "Prix",
									"view": "text",
									"height": 38
								},
								{
									"label": "Taille",
									"view": "text",
									"height": 38
								},
								{
									"label": "Couleur",
									"view": "text",
									"height": 38
								},
								{
									"label": "Visibilité",
									"view": "text",
									"height": 38
								},
								{
									"label": "État",
									"view": "text",
									"height": 38
								},
								{
									"label": "Ajouter produit",
									"view": "button",
									"height": 38
								}
							]
						}
					]
				}
			]
		}
	]
});
}